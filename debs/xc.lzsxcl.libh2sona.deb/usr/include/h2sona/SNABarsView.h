#import "SNAView.h"

@interface SNABarsView : SNAView
@end