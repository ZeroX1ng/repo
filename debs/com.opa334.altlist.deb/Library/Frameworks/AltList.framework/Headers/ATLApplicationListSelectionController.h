#import "ATLApplicationListControllerBase.h"

@interface ATLApplicationListSelectionController : ATLApplicationListControllerBase
{
	NSString* _selectedApplicationID;
}
@end